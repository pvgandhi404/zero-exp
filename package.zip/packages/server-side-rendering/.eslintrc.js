module.exports = {
  ignorePatterns: ['public/**/*', 'static/**/*'],
};
