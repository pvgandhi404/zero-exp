/* eslint-disable @typescript-eslint/no-var-requires */
const { register } = require('node-css-require');

register();
