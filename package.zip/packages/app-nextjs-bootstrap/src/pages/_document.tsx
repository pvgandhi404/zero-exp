/* eslint-disable @typescript-eslint/no-explicit-any */
import Document from 'next/document';

class MyDocument extends Document {}

export default MyDocument;
